# AGENTS.md

Your operating manual for this workspace, written by you. Your main instructions cover how you work in general. This file is where you keep the specific, durable lessons and conventions you pick up as you work, the kind of thing you'd want a future session to know. It's not about the user (that goes in `USER.md` and your memory) or your personality (that's `SOUL.md`); it's about how you get work done here.

## Conventions
Add an entry whenever you work something out worth keeping, for example:
- a convention you've settled on ("keep data exports in `workspace/exports/` and clean them up monthly")
- a tool or site quirk worth remembering ("site X hides its form behind a cookie banner; dismiss it first")
- a workflow that worked, or a mistake not to repeat

It starts empty and is meant to grow slowly. Don't pad it; a short, accurate file beats a long, stale one.

## Conventions

- PodMint/Boltbook session tokens and API keys stored under /tmp vanish without warning (seen 3+ times). Never rely on /tmp for a deadline-bound watch: monitors must report a missing session at once instead of silently passing, and re-authenticate on demand in chat. After a lost register/sign-in reply (empty/timeout), treat it as unknown and get a fresh challenge + fresh signature; never retry the same nonce/signature (a "nonce already used" reply proves the server consumed it, and the key shown only in the lost reply cannot be recovered).
- PodMint/Boltbook APIs are flaky (502s, empty replies, hangs). An empty reply means unknown, not success or failure: verify with a fresh read before concluding anything, and never chain verify+submit in one command (a failed verify must block the submit).
- Boltbook collab: a round failed by reading-window expiry puts the wallet on a 30-min !lfg cooldown (error "you are cooling down: the reading window ended" with an until-time hint); the published !lfg comment stays valid 1h, so re-register the SAME comment_id after the cooldown instead of posting a new comment. Comment creation is NOT subject to the 2-hour post slot limit (that limit is for top-level posts).
- SOLVD API (api.solvd.fun) quirks (seen 2026-10-30): default Python-urllib UA gets Cloudflare/WAF 403 — use a browser User-Agent (same pattern as Boltbook/AgentSea). baw sign-message returns a 64-byte r||s signature plus a separate signatureRecovery ("01"); the SOLVD login expects a 65-byte r||s||v (v = 27 + recovery id, i.e. 0x1c for recovery 1) — sending the raw 64-byte form returns 400 BAD_SIGNATURE. The login endpoint also returned 500 INTERNAL repeatedly on 2026-10-30 (after the format fix), so a 500 there means unknown, not a consumed nonce — verify with a fresh status read before concluding.
- SSH server enabled 2026-11-09 on user request: openssh-server 1:9.6p1-3ubuntu13.20 (direct .deb, apt update too slow via proxy), key-only auth (PasswordAuthentication no, PermitRootLogin prohibit-password), listening :22, enabled at boot. Host ED25519 fingerprint SHA256:m5qSkn0lQMhxof+LlsQUswpfE+7qNd5l7hdqeaMYLnQ. No authorized_keys yet — needs user's public key. Reachability unresolved: VM's only IP is 198.19.0.2/30 host link; built-in Tailscale client accepts no inbound connections.
